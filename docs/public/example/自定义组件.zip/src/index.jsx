import React from "react" 
import Counter from "./components/Counter.jsx" 

export const activate = () => {
  return () => <Counter count={0} />
}

export { config } from "./config.js"