import image from "@rollup/plugin-image"
import { terser } from "rollup-plugin-terser"
import cleanup from "rollup-plugin-cleanup" 
import resolve from "@rollup/plugin-node-resolve" 
import commonjs from "@rollup/plugin-commonjs" 
import { babel } from "@rollup/plugin-babel" 
import replace from "@rollup/plugin-replace" 

export default {
  input: "src/index.jsx",
  output: {
    file: "dist/my-extension.js",
    format: "es"
  },
  plugins: [
    resolve(), 
    commonjs(), 
    babel({ 
      babelHelpers: "runtime", 
      plugins: ["@babel/plugin-transform-runtime"], 
      exclude: "node_modules/**" 
    }), 
    replace({ 
      preventAssignment: true, 
      "process.env.NODE_ENV": JSON.stringify("production") 
    }), 
    image(),
    terser(),
    cleanup() 
  ]
}
