export const activate = () => {
  return () => "<h1>Hello World!</h1>"
}

export { config } from "./config.js"
