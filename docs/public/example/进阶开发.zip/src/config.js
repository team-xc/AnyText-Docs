import logo from "./assets/logo.png"

export const config = {
  name: "My Extension",
  id: "my-extension",
  icon: logo,
  version: "1.0.0",
  engine: "v0.0.1"
}
