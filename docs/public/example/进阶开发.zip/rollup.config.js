import image from "@rollup/plugin-image"
import { terser } from "rollup-plugin-terser"
import cleanup from "rollup-plugin-cleanup" 

export default {
  input: "src/index.js",
  output: {
    file: "dist/my-extension.js",
    format: "es"
  },
  plugins: [
    image(),
    terser(),
    cleanup() 
  ]
}
